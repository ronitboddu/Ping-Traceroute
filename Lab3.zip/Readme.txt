Usage:
go run rb1209_ping.go www.google.com -i 2
go run rb1209_ping.go www.google.com -c 5
go run rb1209_ping.go www.google.com -s 100
go run rb1209_ping.go www.google.com -t 5

cd traceroute
go run rb1209_traceroute.go www.google.com -n
go run rb1209_traceroute.go www.google.com -q 5
go run rb1209_traceroute.go www.google.com -S
